-- Controller
module('luci.controller.auto_ping', package.seeall)